# Public accuracy site: sigir

Built by `tools/public_accuracy/site.py`. 46 patients, 103 protocols.

| What | Where it comes from |
| --- | --- |
| Note text (every word) | **Public source, verbatim** (sigir); see the source's licence in tools/public_accuracy/sources.py and NOTICE |
| Age, sex | **From the source**: the note's own words (English rules of tools/public_site.py) or the source's structured fields; else left empty, never guessed |
| Protocol text | **Public source, verbatim** (inclusion and exclusion lines), plus the lines below |
| age/sex lines written from ClinicalTrials.gov's structured eligibility fields | **Placed or remarked** by the builder |
| Chart numbers, visit dates, birth month, staff, 104 appointments with each trial's investigator | **Placed** (not in the sources; the box needs them to run and to scope SCREEN) |
| Diagnoses, labs, medicines as coded rows | **None**: the note is the whole chart |
| Gold labels | **Not here**: in the gold folder beside this one, never given to the box |
